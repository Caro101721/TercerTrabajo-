// lib/config/router/app_router.dart
import 'package:go_router/go_router.dart';

import '../../presentacion/screens/details_screens.dart';
import '../../presentacion/screens/home_screens.dart'; // Corregido: details_screens.dart

final appRouter = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      name: 'HomeScreen.name',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/details',
      name: DetailsScreen.name,
      builder: (context, state) => const DetailsScreen(),
    ),
  ],
);
