import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DetailsScreen extends StatelessWidget {
  static const name = 'detailsScreen';

  const DetailsScreen({super.key}); // Agrega este constructor

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('Detalle de los productos')),
        elevation: 2,
        backgroundColor: Color(0xfffd1562),
        foregroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Center(
                child: Image.network(
                    'https://i.pinimg.com/736x/5a/0b/d5/5a0bd568ae713f0b60d526efd9c8f057.jpg')),
          )
        ],
      ),
    );
  }
}
