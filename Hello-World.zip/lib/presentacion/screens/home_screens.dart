// lib/presentacion/screens/home_screens.dart
import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';

import 'details_screens.dart'; // Corregido: details_screens.dart

class HomeScreen extends StatelessWidget {
  static const name = 'homeScreen';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: Padding(
            padding: const EdgeInsets.all(5.8),
            child: CircleAvatar(
                backgroundImage: NetworkImage(
                    'https://i.pinimg.com/736x/6b/5f/6d/6b5f6dc5d52e36e126c0e41b7bd8288b.jpg')),
          ),
          title: Text("Bienvenidos a Luxe Piel"),
          centerTitle: true,
        ),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://i.pinimg.com/736x/33/99/b6/3399b6312ea67072aca5dfb9243504b8.jpg',
              width: 150,
              height: 150,
            ),
            const SizedBox(
              height: 20,
            ),
            const Text('Luxe Piel te ofrece los mejores productos para tu piel',
                style: TextStyle(color: Colors.pink)),
            const SizedBox(height: 10),
            const CircularProgressIndicator(strokeWidth: 3),
            const SizedBox(height: 20),
            FilledButton.tonal(
              onPressed: () {
                context.goNamed(DetailsScreen.name);
              },
              child: const Text('ver mas detalles de Luxe'),
            )
          ],
        )));
  }
}
